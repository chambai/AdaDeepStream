# from external.ocl.agents.base import ContinualLearner
# from external.ocl.continuum.data_utils import dataset_transform
# from external.ocl.utils import utils
# from external.ocl.utils.buffer.buffer_utils import random_retrieve
# from external.ocl.utils.setup_elements import transforms_match
# from torch.utils import data
# import numpy as np
# from torch.nn import functional as F
# from external.ocl.utils.utils import maybe_cuda, AverageMeter
# from external.ocl.utils.buffer.buffer import Buffer
# import torch
# import copy
# from traindnn.pytorch_wrapper import DNNPytorchAdaptive
#
# # Deep Stream - Mine!!
# class DeepStream(ContinualLearner):
#     def __init__(self, model, opt, params):
#         super(DeepStream, self).__init__(model, opt, params)
#         self.ds_model = model
#         self.model = self.ds_model.model
#
#     def train_learner(self, x_train, y_train):
#         self.before_train(x_train, y_train)
#         self.ds_model.partial_fit(x_train, y_train)
#         self.prev_model = copy.deepcopy(self.model)
#         self.after_train()
#
#     def update_representation(self, train_loader):
#         pass
