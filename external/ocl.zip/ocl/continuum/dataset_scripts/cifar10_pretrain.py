import numpy as np
from torchvision import datasets
from external.ocl.continuum.data_utils import create_task_composition, load_task_with_labels, shuffle_data
from external.ocl.continuum.dataset_scripts.dataset_base import DatasetBase
from external.ocl.continuum.non_stationary import construct_ns_multiple_wrapper, test_ns


class CIFAR10(DatasetBase):
    def __init__(self, scenario, params):
        dataset = 'cifar10'
        if scenario == 'ni':
            num_tasks = len(params.ns_factor)
        else:
            num_tasks = params.num_tasks
        super(CIFAR10, self).__init__(dataset, scenario, num_tasks, params.num_runs, params)


    def download_load(self):
        dataset_train = datasets.CIFAR10(root=self.root, train=True, download=True)
        self.train_data = dataset_train.data
        self.train_label = np.array(dataset_train.targets)
        dataset_test = datasets.CIFAR10(root=self.root, train=False, download=True)
        self.test_data = dataset_test.data
        self.test_label = np.array(dataset_test.targets)

    def setup(self, x_test, y_test):
        if self.scenario == 'ni':
            self.train_set, self.val_set, self.test_set = construct_ns_multiple_wrapper(self.train_data,
                                                                                        self.train_label,
                                                                                        self.test_data, self.test_label,
                                                                                        self.task_nums, 32,
                                                                                        self.params.val_size,
                                                                                        self.params.ns_type, self.params.ns_factor,
                                                                                        plot=self.params.plot_sample)
        elif self.scenario == 'nc':
            self.test_set.append((x_test, y_test))
        else:
            raise Exception('wrong scenario')

    def new_task(self, cur_task, **kwargs):
        if self.scenario == 'ni':
            x_train, y_train = self.train_set[cur_task]
            labels = set(y_train)
        elif self.scenario == 'nc':
            labels = self.task_labels[cur_task]
            x_train, y_train = load_task_with_labels(self.train_data, self.train_label, labels)
        return x_train, y_train, labels

    def new_run(self, , x_test, y_test, **kwargs):
        self.setup(x_test, y_test)
        return self.test_set

    def test_plot(self):
        test_ns(self.train_data[:10], self.train_label[:10], self.params.ns_type,
                                                         self.params.ns_factor)
