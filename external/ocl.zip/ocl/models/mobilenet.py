"""
Code adapted from https://github.com/facebookresearch/GradientEpisodicMemory
                    &
                  https://github.com/kuangliu/pytorch-cifar
"""
import torch.nn as nn
from torchvision.models.mobilenet import mobilenet_v2

def MobileNetV2(nclasses, nf=20, bias=True):
    """
    Reduced ResNet18 as in GEM MIR(note that nf=20).
    """
    model = mobilenet_v2(pretrained=True)
    num_features = model.classifier[-1].in_features
    # delete original output layer
    del model.classifier[-1]
    # re-add final output layer
    num_class_modules = len([m for m in model.classifier.modules()])
    model.classifier.add_module(str(num_class_modules), nn.Linear(num_features, nclasses))
    return model