from external.ocl.agents.gdumb import Gdumb
from external.ocl.continuum.dataset_scripts.cifar100 import CIFAR100
from external.ocl.continuum.dataset_scripts.cifar10 import CIFAR10
from external.ocl.continuum.dataset_scripts.fashion import Fashion
from external.ocl.continuum.dataset_scripts.core50 import CORE50
from external.ocl.continuum.dataset_scripts.mini_imagenet import Mini_ImageNet
from external.ocl.continuum.dataset_scripts.openloris import OpenLORIS
from external.ocl.agents.exp_replay import ExperienceReplay
from external.ocl.agents.agem import AGEM
from external.ocl.agents.ewc_pp import EWC_pp
from external.ocl.agents.cndpm import Cndpm
from external.ocl.agents.lwf import Lwf
from external.ocl.agents.icarl import Icarl
from external.ocl.agents.scr import SupContrastReplay
from external.ocl.utils.buffer.random_retrieve import Random_retrieve
from external.ocl.utils.buffer.reservoir_update import Reservoir_update
from external.ocl.utils.buffer.mir_retrieve import MIR_retrieve
from external.ocl.utils.buffer.gss_greedy_update import GSSGreedyUpdate
from external.ocl.utils.buffer.aser_retrieve import ASER_retrieve
from external.ocl.utils.buffer.aser_update import ASER_update
from external.ocl.utils.buffer.sc_retrieve import Match_retrieve
from external.ocl.utils.buffer.mem_match import MemMatch_retrieve

data_objects = {
    'cifar100': CIFAR100,
    'cifar10': CIFAR10,
    'mnistfashion': Fashion,
    'core50': CORE50,
    'mini_imagenet': Mini_ImageNet,
    'openloris': OpenLORIS
}

agents = {
    'ER': ExperienceReplay,
    'EWC': EWC_pp,
    'AGEM': AGEM,
    'CNDPM': Cndpm,
    'LWF': Lwf,
    'ICARL': Icarl,
    'GDUMB': Gdumb,
    'SCR': SupContrastReplay,
}

retrieve_methods = {
    'MIR': MIR_retrieve,
    'random': Random_retrieve,
    'ASER': ASER_retrieve,
    'match': Match_retrieve,
    'mem_match': MemMatch_retrieve

}

update_methods = {
    'random': Reservoir_update,
    'GSS': GSSGreedyUpdate,
    'ASER': ASER_update
}

