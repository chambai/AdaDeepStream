import multiprocessing
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import torch
from torch.nn import CrossEntropyLoss
from torch.optim.adam import Adam
import numpy as np

import external.rsb.data.data_collection as data_col
from external.rsb.data.stream import ClassStream, InstanceStream
from external.rsb.test.test_stream import DummyDataset
from external.rsb.eval.eval import ClassStreamEvaluator, InstanceStreamEvaluator
from external.rsb.eval.experiment_ds import Experiment
from external.rsb.learners.nnet import NeuralNet
from external.rsb.learners.er import ExperienceReplay, ClassBuffer, SubspaceBuffer, ReactiveSubspaceBuffer

from core.dnn_models import DNNPytorchAdaptive
from external.external_interface import DsExternalInterface

num_cores = multiprocessing.cpu_count()

class DeepStreamRunner(DsExternalInterface):

    def __init__(self, ds_model, ds_optimizer):
        super(DeepStreamRunner, self).__init__()
        self.ds_model = ds_model
        self.ds_optimizer = ds_optimizer
        self.eer = None
        pass

    def fit(self, X, y):
        # make classes consecutive so the DNN can be trained
        self.setup_class_map(y)
        X, y = self.transform_input_data(X, y)

        X = np.array(X, dtype=np.float32)
        X = torch.from_numpy(X)
        X = X.permute(0, 3, 1, 2)
        y = torch.from_numpy(y)
        self.eer = ExperimentExperienceReplay(self.ds_model, self.ds_optimizer)
        self.ds_model, _ = self.eer.run(X, y, algorithms=['ER-RSB10x100'],
                                         streams=['DS-REC-TENSOR-S1'],
                                         evaluators=['IncEval-ep10'],
                                     is_train=True
                                     )
        pass

    def partial_fit(self, X, y):
        # make classes consecutive
        X, y = self.transform_input_data(X, y)

        X = np.array(X, dtype=np.float32)
        X = torch.from_numpy(X)
        X = X.permute(0, 3, 1, 2)
        y = torch.from_numpy(y)
        self.ds_model, predictions = self.eer.run(X, y, algorithms=['ER-RSB10x100'],
                                streams=['DS-REC-TENSOR-S1'],
                                evaluators=['IncEval-ep10'],
                                is_train=False
                                     )
        predictions = self.transform_ouput_data(predictions)
        return self.ds_model, predictions



class ExperimentExperienceReplay(Experiment):

    def __init__(self, ds_model, ds_optimizer):
        super(ExperimentExperienceReplay, self).__init__()
        self.ds_model = ds_model
        self.ds_optimizer = ds_optimizer
        self.classes = []
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        pass

    def mlp_creator(self):
        if self.ds_model.classifier[-1].out_features < len(self.classes):
            # add new outputs to DNN
            dnn_pt = DNNPytorchAdaptive()
            net = dnn_pt.get_new_model_final_layer(self.ds_model, len(self.classes))
        else:
            net = self.ds_model
        optimizer = self.ds_optimizer
        return NeuralNet(net, CrossEntropyLoss(), optimizer, None, device=self.device)


    def prepare(self, is_train, X, y):
        torch.multiprocessing.set_sharing_strategy('file_system')
        logdir_root = 'runs/er'
        self.classes.extend(np.sort(np.unique(y)))

        if is_train:
            self.add_algorithm_creator('NN', lambda: self.mlp_creator())
            self.add_algorithm_creator('ER-CB-2000-p0', lambda: ExperienceReplay(self.mlp_creator(), ClassBuffer(buffer_max_size=2000, replace_prob=0.0)))
            self.add_algorithm_creator('ER-CB-2000-p1', lambda: ExperienceReplay(self.mlp_creator(), ClassBuffer(buffer_max_size=2000, replace_prob=1.0)))
            self.add_algorithm_creator('ER-SB10x100', lambda: ExperienceReplay(self.mlp_creator(), SubspaceBuffer(max_centroids=10, max_instances=100)))
            self.add_algorithm_creator('ER-SB20x100', lambda: ExperienceReplay(self.mlp_creator(), SubspaceBuffer(max_centroids=20, max_instances=100)))
            self.add_algorithm_creator('ER-RSB10x100', lambda: ExperienceReplay(self.mlp_creator(),
                                                                                ReactiveSubspaceBuffer(max_centroids=10, max_instances=100,
                                                                                                       window_size=100, split=True)))
            self.add_algorithm_creator('ER-RSB20x100', lambda: ExperienceReplay(self.mlp_creator(),
                                                                                ReactiveSubspaceBuffer(max_centroids=20, max_instances=100,
                                                                                                       window_size=100, split=True)))

        # streams = [
        #     ('MNIST-REC-TENSOR', 'MNIST-TRAIN-TENSOR', 'MNIST-TEST-TENSOR'),
        #     ('FASHION-REC-TENSOR', 'FASHION-TRAIN-TENSOR', 'FASHION-TEST-TENSOR'),
        #     ('SVHN-REC-TENSOR', 'SVHN-TRAIN-TENSOR', 'SVHN-TEST-TENSOR'),
        #     ('IMAGENET10-REC-TENSOR', 'IMAGENET10-TRAIN-TENSOR', 'IMAGENET10-TEST-TENSOR'),
        #     ('CIFAR10-REC-TENSOR', 'CIFAR10-TRAIN-TENSOR', 'CIFAR10-TEST-TENSOR')
        # ]
        streams = [('DS-REC-TENSOR', 'DS-TRAIN-TENSOR', 'DS-TEST-TENSOR')]

        # rec_seq_stat_10 = [(0, [0], {0: 1}), (1, [1], {1: 0}), (2, [2], {2: 1}), (3, [3], {3: 0}), (4, [4], {4: 1}),
        #                    (5, [5], {5: 0}), (6, [6], {6: 1}), (7, [7], {7: 0}), (8, [8], {8: 1}), (9, [9], {9: 0})]

        def data_creator(X, y, is_train):
            if is_train:
                init_frac = 1.0
            else:
                init_frac = 0.0
            return lambda: InstanceStream(DummyDataset(X, y), init_frac=init_frac)

        for name, train, test in streams:
            self.add_data_creator(f'{name}-S1', data_creator(X, y, is_train))

        # rec_seq_drift_2_20 = [(0, [0], {0: 1}), (1, [1], {1: 0}), (2, [2], {2: 1}), (3, [3], {3: 0}),
        #                       (0, [0], {0: 0}), (1, [1], {1: 1}),
        #                       (4, [4], {4: 1}), (5, [5], {5: 0}), (6, [6], {6: 1}),
        #                       (2, [2], {2: 0}), (3, [3], {3: 1}),
        #                       (7, [7], {7: 0}), (8, [8], {8: 1}), (9, [9], {9: 0}),
        #                       (4, [4], {4: 0}), (5, [5], {5: 1}),
        #                       (0, [0], {0: 0}), (1, [1], {1: 1}), (2, [2], {2: 0}),
        #                       (6, [6], {6: 0}), (7, [7], {7: 1}),
        #                       (3, [3], {3: 1}), (4, [4], {4: 0}), (5, [5], {5: 1}),
        #                       (8, [8], {8: 0}), (9, [9], {9: 1}),
        #                       (0, [0], {0: 0}), (1, [1], {1: 1}), (2, [2], {2: 0}), (3, [3], {3: 1})]
        #
        # for name, train, test in streams:
        #     self.add_data_creator(f'{name}-D1', data_creator(train, test, rec_seq_drift_2_20))

        self.add_evaluator_creator('IncEval-ep10',
                               lambda: InstanceStreamEvaluator(batch_size=100, shuffle=False, logdir_root=logdir_root,
                                                            numpy=False))

    def create_data(self, X, y):
        streams = [('DS-REC-TENSOR', 'DS-TRAIN-TENSOR', 'DS-TEST-TENSOR')]

        for i in np.sort(np.unique(y.cpu().detach().numpy())):
            if i not in self.classes:
                self.classes.append(i)

        def data_creator(X, y):
            return lambda: InstanceStream(DummyDataset(X, y), init_frac=0.0)

        for name, train, test in streams:
            self.add_data_creator(f'{name}-S1', data_creator(X, y))



        # self.add_evaluator_creator('IncEval-ep10', lambda: ClassStreamEvaluator(batch_size=256, shuffle=True, num_epochs=10,
        #                                                                    num_workers=8, logdir_root=logdir_root,
        #                                                                    numpy=False, vis=False))
        #
        # self.add_evaluator_creator('IncEval-ep5', lambda: ClassStreamEvaluator(batch_size=256, shuffle=True, num_epochs=5,
        #                                                                    num_workers=8, logdir_root=logdir_root,
        #                                                                    numpy=False, vis=False))


# def run():
#
#     # Stationary
#     ExperimentExperienceReplay().run(algorithms=['NN', 'ER-CB-2000-p0', 'ER-CB-2000-p1'],
#                                      streams=['CIFAR10-REC-TENSOR-S1', 'SVHN-REC-TENSOR-S1',
#                                               'FASHION-REC-TENSOR-S1', 'MNIST-REC-TENSOR-S1', 'IMAGENET10-REC-TENSOR-S1'],
#                                      evaluators=['IncEval-ep10'])
#
#     ExperimentExperienceReplay().run(algorithms=['ER-SB10x100', 'ER-RSB10x100'],
#                                      streams=['CIFAR10-REC-TENSOR-S1', 'SVHN-REC-TENSOR-S1', 'MNIST-REC-TENSOR-S1'],
#                                      evaluators=['IncEval-ep10'])
#
#     ExperimentExperienceReplay().run(algorithms=['ER-SB20x100', 'ER-RSB20x100'],
#                                      streams=['FASHION-REC-TENSOR-S1'],
#                                      evaluators=['IncEval-ep10'])
#
#     ExperimentExperienceReplay().run(algorithms=['ER-SB10x100', 'ER-RSB10x100'],
#                                      streams=['IMAGENET10-REC-TENSOR-S1'],
#                                      evaluators=['IncEval-ep5'])
#
#     # Drifting
#     ExperimentExperienceReplay().run(algorithms=['NN', 'ER-CB-2000-p0', 'ER-CB-2000-p1'],
#                                      streams=['CIFAR10-REC-TENSOR-D1', 'SVHN-REC-TENSOR-D1',
#                                               'FASHION-REC-TENSOR-D1', 'MNIST-REC-TENSOR-D1', 'IMAGENET10-REC-TENSOR-D1'],
#                                      evaluators=['IncEval-ep10'])
#
#     ExperimentExperienceReplay().run(algorithms=['ER-SB10x100', 'ER-RSB10x100'],
#                                      streams=['CIFAR10-REC-TENSOR-D1', 'SVHN-REC-TENSOR-D1', 'MNIST-REC-TENSOR-D1'],
#                                      evaluators=['IncEval-ep10'])
#
#     ExperimentExperienceReplay().run(algorithms=['ER-SB20x100', 'ER-RSB20x100'],
#                                      streams=['FASHION-REC-TENSOR-D1'],
#                                      evaluators=['IncEval-ep10'])
#
#     ExperimentExperienceReplay().run(algorithms=['ER-SB10x100', 'ER-RSB10x100'],
#                                      streams=['IMAGENET10-REC-TENSOR-D1'],
#                                      evaluators=['IncEval-ep5'])
