from external.rsb.core.clearn import ContinualLearner
from external.rsb.data.stream import Stream
from external.rsb.eval.eval_ds import Evaluator

import itertools
from abc import ABC, abstractmethod
from typing import List, Dict, Callable
from torch.utils.data import Dataset


class Experiment(ABC):

    def __init__(self):
        self.algorithms: Dict[str, Callable[[], ContinualLearner]] = {}
        self.streams: Dict[str, Callable[[], Stream]] = {}
        self.evaluators: Dict[str, Callable[[], Evaluator]] = {}
        self.evaluator_objs = {}

    def run(self, X, y, algorithms: List[str] = None, streams: List[str] = None, evaluators: List[str] = None, is_train=False):
        model = None
        predictions = None
        if is_train:
            self.prepare(is_train, X, y)
            algorithms = self.algorithms.keys() if not algorithms else algorithms
            streams = self.streams.keys() if not streams else streams
            evaluators = self.evaluators.keys() if not evaluators else evaluators

            for a, s, e, in itertools.product(algorithms, streams, evaluators):
                print(f'Running for: {a}, {s}, {e}')
                self.evaluator_objs[e] = self.evaluators[e]()
                model, _ = self.evaluator_objs[e].evaluate((a, self.algorithms[a]), (s, self.streams[s]))
        else:
            self.create_data(X, y)
            self.evaluator_objs['IncEval-ep10'].model.model = self.mlp_creator()
            a = 'ER-RSB10x100'
            s = 'DS-REC-TENSOR-S1'
            model, predictions = self.evaluator_objs['IncEval-ep10'].evaluate((a, self.algorithms[a]), (s, self.streams[s]))


        return model, predictions

    def add_algorithm_creator(self, label: str, algorithm: Callable[[], ContinualLearner]):
        self.algorithms[label] = algorithm

    def add_data_creator(self, label: str, stream: Callable[[], Stream]):
        self.streams[label] = stream

    def add_evaluator_creator(self, label: str, evaluator: Callable[[], Evaluator]):
        self.evaluators[label] = evaluator

    @abstractmethod
    def prepare(self):
        pass
