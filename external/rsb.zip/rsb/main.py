import rsb.benchmark.er_runner as er_runner
import rsb.benchmark.extractors as extractor


def main():
    # extractor.extract()
    er_runner.run()


# if __name__ == '__main__':
#     main()
